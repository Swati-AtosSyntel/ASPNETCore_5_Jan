﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplicationDay1.Models;

namespace WebApplicationDay1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            Book b = new Book() { BookID = 123, BookName = "Asp.NET Core" };
            return View(b);
        }
    }
}